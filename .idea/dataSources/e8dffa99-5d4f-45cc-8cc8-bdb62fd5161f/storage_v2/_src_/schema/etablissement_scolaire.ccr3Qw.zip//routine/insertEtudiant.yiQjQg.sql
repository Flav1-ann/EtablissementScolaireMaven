create
    definer = root@localhost procedure insertEtudiant(IN e_nom varchar(50), IN e_prenom varchar(50),
                                                      IN e_email varchar(50), IN e_adresse varchar(50),
                                                      IN e_telephone varchar(50), IN e_mdp varchar(50),
                                                      IN e_salt varchar(50), IN e_nom_role varchar(50),
                                                      IN e_date_naissance date, OUT erreur int)
BEGIN
    DECLARE personne_id INT DEFAULT 0;
    DECLARE is_row_exist INT;

    SELECT EXISTS(SELECT * from personne WHERE personne.email = e_email) as is_exist into is_row_exist;

    START TRANSACTION;
    INSERT INTO `personne`(`nom`, `email`, `adresse`, `telephone`) 
    VALUES (e_nom, e_email, e_adresse, e_telephone);
    SET personne_id = LAST_INSERT_ID();
    IF (personne_id > 0) && (is_row_exist != 1) THEN
        INSERT INTO `personne_phys`(`id_phys`, `prenom`, `mdp`, `salt`, `id_role`) 
        VALUES (personne_id, e_prenom, e_mdp, e_salt, (SELECT id_role from role where role.libelle = e_nom_role) );
        INSERT INTO `etudiant`(`id_etudiant`, `date_naissance`) 
        VALUES (personne_id, e_date_naissance);
        SET erreur = 0;
        COMMIT;
    ELSEIF personne_id = 0 THEN
        SET erreur = -1;
        ROLLBACK;
    ELSEIF is_row_exist = 1 THEN
        SET erreur = -2;
        ROLLBACK;
    END IF;
END;


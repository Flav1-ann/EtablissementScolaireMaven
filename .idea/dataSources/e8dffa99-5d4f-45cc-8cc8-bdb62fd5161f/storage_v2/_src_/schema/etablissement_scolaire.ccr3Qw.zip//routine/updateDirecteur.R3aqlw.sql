create
    definer = root@localhost procedure updateDirecteur(IN dir_id_directeur int, IN dir_nom varchar(50),
                                                       IN dir_prenom varchar(50), IN dir_email varchar(50),
                                                       IN dir_adresse varchar(50), IN dir_telephone varchar(50),
                                                       IN dir_mdp varchar(50), IN dir_salt varchar(50),
                                                       IN dir_nom_role varchar(50), OUT erreur int)
BEGIN
    DECLARE is_row_updated INT;
    START TRANSACTION;
    
    IF dir_id_directeur > 0 THEN

        -- Update personne
        UPDATE `personne`
        SET `nom`=dir_nom,`email`=dir_email,`adresse`=dir_adresse,`telephone`=dir_telephone 
        WHERE personne.id_personne = dir_id_directeur;
        
        SET is_row_updated = ROW_COUNT();
       
        IF is_row_updated = 1 THEN
            
            -- Update personne_phys
            UPDATE `personne_phys` 
            SET `prenom`=dir_prenom,`mdp`=dir_mdp,`salt`=dir_salt, `id_role`= (SELECT id_role from role where role.libelle = dir_nom_role)
            WHERE personne_phys.id_phys = dir_id_directeur;
            SET erreur = 0;
            COMMIT;
        ELSE
            SET erreur = -1;
            ROLLBACK;
        END IF;
        -- Commit queries
    ELSE
        -- Commit if id isn't correct ROLLBACK to cancel any actions did before
        ROLLBACK;
    END IF;
END;


create
    definer = root@localhost procedure deleteDirecteur(IN dir_id_directeur int, OUT erreur int)
BEGIN
    DECLARE is_row_deleted INT;
    START TRANSACTION;
    
    IF dir_id_directeur > 0 THEN
    
        -- Update personne

        DELETE FROM `personne`
        WHERE personne.id_personne = dir_id_directeur;
        
        SET is_row_deleted = ROW_COUNT();
       
        IF is_row_deleted = 1 THEN
            -- Update personne_phys
            
            DELETE FROM `personne_phys`
            WHERE personne_phys.id_phys = dir_id_directeur;
            
            -- Update étudiant 
            
            DELETE FROM `directeur`
            WHERE directeur.id_dir = dir_id_directeur;
            
            -- Commit queries
            SET erreur = 0;
            COMMIT;
        ELSE 
            SET erreur = -1;
            ROLLBACK;
        END IF;
    ELSE
        -- Commit if id isn't correct ROLLBACK to cancel any actions did before
        ROLLBACK;
    END IF;
END;


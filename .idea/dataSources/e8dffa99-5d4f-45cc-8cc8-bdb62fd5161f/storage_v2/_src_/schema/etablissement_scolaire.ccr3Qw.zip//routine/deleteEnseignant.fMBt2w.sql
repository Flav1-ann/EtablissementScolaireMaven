create
    definer = root@localhost procedure deleteEnseignant(IN en_id_enseignant int, OUT erreur int)
BEGIN
    DECLARE is_row_deleted INT;

    START TRANSACTION;
    
    IF en_id_enseignant > 0 THEN
    
        -- Update personne

        DELETE FROM `personne`
        WHERE personne.id_personne = en_id_enseignant;
        
        SET is_row_deleted = ROW_COUNT();
       
        IF is_row_deleted = 1 THEN
            -- Update personne_phys
            
            DELETE FROM `personne_phys`
            WHERE personne_phys.id_phys = en_id_enseignant;
            
            -- Update étudiant 
            
            DELETE FROM `enseignant`
            WHERE enseignant.id_ens = en_id_enseignant;
            
            -- Commit queries
            SET erreur = 0;
            COMMIT;
        ELSE
            SET erreur = -1;
            ROLLBACK;
        END IF;
    ELSE
        -- Commit if id isn't correct ROLLBACK to cancel any actions did before
        ROLLBACK;
    END IF;
END;


create
    definer = root@localhost procedure deleteResponsable(IN res_id_responsable int, OUT erreur int)
BEGIN
    DECLARE is_row_deleted INT;

    START TRANSACTION;
    
    IF res_id_responsable > 0 THEN
    
        -- Update personne
       
        DELETE FROM `personne`
        WHERE personne.id_personne = res_id_responsable;
       
        SET is_row_deleted = ROW_COUNT();
       
        IF is_row_deleted = 1 THEN
            -- Update personne_phys
        
            DELETE FROM `personne_phys`
            WHERE personne_phys.id_phys = res_id_responsable;
        
            -- Update étudiant 
            
            DELETE FROM `res_etude`
            WHERE res_etude.id_res = res_id_responsable;
            
            -- Commit queries
            SET erreur = 0;
            COMMIT;
        ELSE
            SET erreur = -1;
            ROLLBACK;
        END IF;
    ELSE
        -- Commit if id isn't correct ROLLBACK to cancel any actions did before
        ROLLBACK;
    END IF;
END;


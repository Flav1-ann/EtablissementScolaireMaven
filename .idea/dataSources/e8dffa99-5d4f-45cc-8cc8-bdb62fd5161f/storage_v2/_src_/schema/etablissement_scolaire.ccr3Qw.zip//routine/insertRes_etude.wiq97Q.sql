create
    definer = root@localhost procedure insertRes_etude(IN res_nom varchar(50), IN res_prenom varchar(50),
                                                       IN res_email varchar(50), IN res_adresse varchar(50),
                                                       IN res_telephone varchar(50), IN res_mdp varchar(50),
                                                       IN res_salt varchar(50), IN res_nom_role varchar(50),
                                                       OUT erreur int)
BEGIN
    DECLARE personne_id INT DEFAULT 0;
    DECLARE is_row_exist INT;

    SELECT EXISTS(SELECT * from personne WHERE personne.email = res_email) as is_exist into is_row_exist;

    START TRANSACTION;
    INSERT INTO `personne`(`nom`, `email`, `adresse`, `telephone`) 
    VALUES (res_nom, res_email, res_adresse, res_telephone);
    SET personne_id = LAST_INSERT_ID();
    IF (personne_id > 0) && (is_row_exist != 1) THEN
        INSERT INTO `personne_phys`(`id_phys`, `prenom`, `mdp`, `salt`, `id_role`) 
        VALUES (personne_id, res_prenom, res_mdp, res_salt, (SELECT id_role from role where role.libelle = res_nom_role) );
        INSERT INTO `res_etude`(`id_res`) VALUES (personne_id);
        SET erreur = 0;
        COMMIT;
    ELSEIF personne_id = 0 THEN
        SET erreur = -1;
        ROLLBACK;
    ELSEIF is_row_exist = 1 THEN
        SET erreur = -2;
        ROLLBACK;
    END IF;
END;


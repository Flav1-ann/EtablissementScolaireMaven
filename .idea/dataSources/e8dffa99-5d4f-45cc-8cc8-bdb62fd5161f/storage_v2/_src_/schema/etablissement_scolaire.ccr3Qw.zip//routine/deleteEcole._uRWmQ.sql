create
    definer = root@localhost procedure deleteEcole(IN ec_id_ecole int, OUT erreur int)
BEGIN
    DECLARE is_row_deleted INT;

    START TRANSACTION;
    
    IF ec_id_ecole > 0 THEN
    
        DELETE FROM `personne`
        WHERE personne.id_personne = ec_id_ecole;

        SET is_row_deleted = ROW_COUNT();
       
        IF is_row_deleted = 1 THEN
            
            DELETE FROM `personne_phys`
            WHERE personne_phys.id_phys = ec_id_ecole;

            DELETE FROM `ecole`
            WHERE ecole.id_ecole = ec_id_ecole;

            -- Commit queries
            SET erreur = 0;
            COMMIT;
        ELSE
            SET erreur = -1;
            ROLLBACK;
        END IF;
    ELSE
        
        -- Commit if id isn't correct ROLLBACK to cancel any actions did before
        ROLLBACK;
    END IF;
END;

